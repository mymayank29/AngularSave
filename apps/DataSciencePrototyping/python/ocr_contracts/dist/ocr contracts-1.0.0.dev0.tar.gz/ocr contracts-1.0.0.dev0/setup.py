from setuptools import setup

setup(
    name='ocr contracts',
    version='1.0.0dev',
    packages=['ocr_contracts'],
    license='Chevron',
    author='hqej',
    author_email='hqej',
    description='OCR contracts'
)
